﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7
{
    class Program
    {
        static double f(int x)
        {
            try
            {
                if (x == 2) throw new Exception();
                else return x/(Math.Sqrt(x*x - 1));
            }
            catch
            {
                throw;
            }
        }
        static void Main(string[] args)
        { 
                    try
                    {
                        Console.Write("a=");
                        int a = int.Parse(Console.ReadLine());
                        Console.Write("b=");
                        int b = int.Parse(Console.ReadLine());
                        Console.Write("h=");
                        int h = int.Parse(Console.ReadLine());
                        for (int i = a; i <= b; i += h)
                            try
                            {
                                Console.WriteLine("y({0})={1:f4}", i, f(i));
                            }
                            catch
                            {
                                Console.WriteLine("y({0})=error", i);
                            }
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Неверный формат ввода данных");
                    }
                    catch
                    {
                        Console.WriteLine("Неизвестная ошибка");
                    }
            Console.ReadKey();
        }
    }
}

