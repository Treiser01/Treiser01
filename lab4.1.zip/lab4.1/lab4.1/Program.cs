﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab4._1
{
    class Program
    {
        static void Main(string[] args)
        {
            double A = -0.09;
            int I = -6;
            double C = Math.Pow(10,-5);
            bool L = false;
            string NAME = "Treiser";

            Console.WriteLine(" A = {0:f2} \n I = {1:d} \n C = {2:f3} \n L = {3:w} \n NAME = {4:w} \n", A, I, C, L, NAME);
            Console.ReadKey();
        }
    }
}
