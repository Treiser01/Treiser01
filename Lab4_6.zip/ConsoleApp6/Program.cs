﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            double x = 3 , y = 2;
            int N;

            Console.Write("Введите х ");
            x = double.Parse(Console.ReadLine());
            Console.Write("Введите y ");
            y = double.Parse(Console.ReadLine());
            if (x <= 0) 
            {
                if (x * x + y * y >= 64) 
                {if (y >= 0) N = 3; else N = 4; }
                { if (y >= 0) N = 1; else N = 2; }   
            }
            else
               { if (y >= 0) N = 3; else N = 4; }


            Console.WriteLine("N = {0}", N);
            Console.ReadKey();



        }
    }
}
