﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, S, n, Step1, Step2, delta;
            int i;
            S = 1;
            n = 20;
            x = 0.1;
            for (i = 1; i <= n; i++) 
            {
                Step1 = Math.Pow(-1, i);
                Step2 = Math.Pow(x, i);
                S = S + Step1 * Step2;
            }
            delta = S - 1 / (1 + x);
            Console.WriteLine("delta={0:F20}", delta);
            Console.ReadKey();
        }
    }
}
