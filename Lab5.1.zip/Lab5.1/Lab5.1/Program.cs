﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5._1
{
    class Program
    {
        static void Main(string[] args)
        {
            double max, min, x, y,  F;
            x = 1;
            y = 2;
            max = x*x+y*y > x-y  ? x-y : x*x + y*y ;
            min = (x > y) ? x : y;
            F = (max * x) / (min * min + Math.Pow(y,4));
            Console.WriteLine(F);
            Console.ReadKey();
        }
    }
}
