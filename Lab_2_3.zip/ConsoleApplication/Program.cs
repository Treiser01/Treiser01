﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication
{
    class Program
    {
        static void Main()
        {
      
            Console.WriteLine("Введите трехзначное число");
            int a =234;
            int e = (a / 10) % 10;
            int b = a / 100;
            int c = a % 10;
            int sum = e + b + c;
            Console.WriteLine("{0}", b);
            Console.WriteLine("{1}", e);
            Console.WriteLine("{2}", c);
            Console.WriteLine("{0}+{1}+{2}",b,e,c);
            Console.ReadKey();
        }
    }
}
