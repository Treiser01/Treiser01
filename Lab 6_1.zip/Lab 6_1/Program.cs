﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_6_1
{
    class Program
    {

        static void Main(string[] args)
        {
            float a, x, y;
            for (a = 1f; a <= 4; a += 1f)
            {
                Console.WriteLine("a={0}", a);
                for (x = -4; x <= 4; x += 0.2f)
                {
                    y = (float) (Math.Pow(x + a, x / a)- (Math.Pow(x - a, x / a)))/ a;
                    Console.WriteLine("x=" + x + '\t' + "y=" + y);
                }
                Console.WriteLine("\n");
                Console.ReadKey();
            }
        }
    }
}

