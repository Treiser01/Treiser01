﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            double y, z;
            Console.Write("Введите число X");
            y = double.Parse(Console.ReadLine());
            
             if (y >= 1 | y <=2)
                 {
                    z = Math.Pow(y, 1 / 3) + Math.E * y;
                    Console.WriteLine("={0}", z);
                }
            if (y > 3 | y <= 5)
                 {
                    z = y + 2;
                    Console.WriteLine("z={0}", z);
                 }
            if (y > 7)
            {
                z = Math.Atan(y) - Math.Pow(y, 1 / 3);
                Console.WriteLine("z={0}", z);
            }
           
        }
    }
}
