﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    class Program
    {
        static void Main(string[] args)
        {
            double x , y ;
            int N;

            Console.Write("Введите х ");
            x = double.Parse(Console.ReadLine());
            Console.Write("Введите y ");
            y = double.Parse(Console.ReadLine());


            if (x <= 0)
            {
                if (y <= 0)

                {
                    if (y > -x - 12) N = 1; else N = 3;
                }
                else
                {
                    if (y > -x + 12) N = 3; else N = 2;
                }

            }
            else





            {
                if (y >= 0)

                {
                    if (y > x + 12) N = 4; else N = 1;
                }
                else
                {
                    if (y > x - 12) N = 2; else N = 4;
                }
            }

            Console.WriteLine("N = {0}", N);
            Console.ReadKey();



        }
    }
}
