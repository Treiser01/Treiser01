﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_2
{
    class Program
    {

        static void Main(string[] args)
        {
            float x, y, S=0,m, r;

            Console.Write("Введите x: ");
            x = float.Parse(Console.ReadLine());

            Console.Write("Введите колличество повторений функции: ");
            m = int.Parse(Console.ReadLine());

            for (int i = 1; i <= m; i++)
            {
                double step = Math.Acos(x);
                S = S+(float)step / Fact(i);
            }
            r = 1 + S;
            y = (float)Math.Acos(x);
            if (x == 1)
                y = (float)Math.Acos(x);
            if (x == 0)
                y = 1;

            Console.WriteLine("Результат: {0:f3} \nY = {1:f3}",r,y);
            Console.ReadKey();
        }
        static int Fact(int i)
        {
            if (i == 0 || i == 1)
            {
                return 1;
            }
            return i = i * Fact(i - 1);
        }
       
    }
}
