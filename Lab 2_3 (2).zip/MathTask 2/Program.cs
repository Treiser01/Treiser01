﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathTask
{


    class Program
    {

        #region Переменные круга         
        private double TF;
        private double TC;
        #endregion

        #region Переменные задачи о ладье 

        private byte x1;
        private byte y1;
        private byte x2;
        private byte y2;
        #endregion 

        #region Переменные задачи о числе 

        private string value;
        private byte a;
        private byte b;
        private byte c;
        private int result;
        #endregion

        static void Main(string[] args)
        {
            Program ex = new Program();
            ex.FirstTask();
            ex.SecondTask();
            ex.ThirdTask();
            Console.ReadLine();
        }

        private void FirstTask()
        {
            
            Console.Write("Ведите число TF");
            TF = double.Parse(Console.ReadLine());
            TC = (TF - 32) * 5 / 9;
            Console.WriteLine("TC={0}", TC);

            





            Console.ReadKey();
 
        }
        private void SecondTask()
        {
            //Проверить может ли попасть ладья за один ход из поля заданного 
            //координатами x1,y1 в поле заданное координатами x2,y2             
            Console.WriteLine("Введите вертикаль на которой находится ладья):");
            this.x1 = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Введите горизонталь на которой находится ладья):");
            this.y1 = Convert.ToByte(Console.ReadLine());

            Console.WriteLine("Введите вертикаль поля на которое должна попасть ладья):");
            this.x2 = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Введите горизонталь поля на которое должна попасть ладья):");
            this.y2 = Convert.ToByte(Console.ReadLine());

            if (x1 == x2 || y1 == y2)
            {
                Console.WriteLine("Данный ход ладьи возможен.");
            }
            else
            {
                Console.WriteLine("Данный ход ладьи невозможен!");
            }
        }
        private void ThirdTask()
        {
            //Дано трёхзначное число, найти сумму произведения его цифр             
            do
            {
                Console.WriteLine("Введите число:");
                this.value = Console.ReadLine();
            } while (value.Length != 3);

            this.a = byte.Parse(value[0].ToString());
            this.b = byte.Parse(value[1].ToString());
            this.c = byte.Parse(value[2].ToString());


            this.result = (a * b) + (a * c) + (b * c);

            Console.WriteLine("Сумма произведения трёх цифр:{0}",
          this.result);
        }

    }
}
