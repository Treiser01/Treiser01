﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_8
{
    class Program
    {


        static void P(ref int sum, double x)
        {
            for (int i = 1; i <= 10; i++)
                sum += Convert.ToInt32(Math.Log(i * Math.Pow(x, i)));
        }
        static void Main(string[] args)
        {
            int sum = 0;
            Console.Write("Введите x:");
            double x = int.Parse(Console.ReadLine());
            P(ref sum, x);
            Console.WriteLine("{0:f8}", sum);
            Console.ReadKey();
        }


    }
}
